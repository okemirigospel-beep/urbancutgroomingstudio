# Draft catalogue and academy content

All figures are illustrative NGN placeholders, not approved prices. Service variants and descriptions require owner review. Durations are unconfirmed.

| Category | Sample service | Sample price | Draft description |
|---|---|---|---|
| Barbering and grooming | Adult haircut | ₦7,000 | A haircut shaped around your preferred look. |
| Barbering and grooming | Children’s haircut | ₦4,000 | A neat haircut for a younger client. |
| Barbering and grooming | Beard shape-up | ₦3,500 | Beard shaping for a clean outline. |
| Barbering and grooming | Hair colouring | ₦10,000 | Colour application; exact options require confirmation. |
| Barbering and grooming | Wave styling | ₦6,000 | Styling focused on a defined wave look. |
| Loc services | Starter locs | ₦18,000 | An introductory loc installation service. |
| Loc services | Loc maintenance | ₦12,000 | Maintenance and tidying of existing locs. |
| Loc services | Loc extensions | ₦35,000 | Extension work for a loc style; materials to be confirmed. |
| Braiding | Men’s braids | ₦10,000 | Braiding tailored to a chosen style. |
| Braiding | Women’s braids | ₦18,000 | Braiding options; lengths and materials to be confirmed. |
| Home services | Abuja home grooming enquiry | ₦15,000 | Request a home visit within Abuja; scope and travel fee to be confirmed. |

Coming soon, excluded from selection: manicure, pedicure, massage, spa. Facials: status unconfirmed, keep draft/unbookable. Draft add-on examples: beard finishing and styling finish; do not enable until scoped to avoid overlap with standalone services.

Products coming soon: beard oil — sample ₦8,000; beard balm — sample ₦7,000; styling cream — sample ₦6,000. No stock, sizes, ingredients or efficacy claims are established.

## Proposed academy ladder
Every row is provisional, including the first row: the owner suggested ₦110,000/four months as a framework example. Levels are progressive descriptions, not a verified prerequisite system.

| Level | Draft title | Sample fee | Sample duration | Draft learning outline |
|---|---|---|---|
| 1 | Urban Cuts Foundation Academy | ₦110,000 | 4 months | Tool familiarisation, hygiene basics, client consultation and introductory haircutting. |
| 2 | Urban Cuts Elevated Skills | ₦160,000 | 4 months | Sectioning, blending, introductory fades and beard shaping. |
| 3 | Urban Cuts Professional Grooming | ₦230,000 | 5 months | Advanced haircut practice, styling, service consistency and client care. |
| 4 | Urban Cuts Advanced Artistry | ₦320,000 | 5 months | Creative finishing, introductory braiding/loc techniques and corrective practice. |
| 5 | Urban Cuts Mastery Programme | ₦450,000 | 6 months | Complex practical work, portfolio development and studio workflow fundamentals. |

Academy CTA: Enquire about training. Formal application process, prerequisites, materials, certificates and dates remain pending.
