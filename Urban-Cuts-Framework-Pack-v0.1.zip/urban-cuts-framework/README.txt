Urban Cuts Grooming Studio — Framework pack v0.1

Start with 00-work-brief.md. Supply the full folder to Codex and use 03-master-framework-prompt.txt to begin. The ten section prompts are modular refinement instructions, not ten competing design systems. Draft catalogue and FAQ are editable inputs. This pack specifies a private initial framework, not a public launch or production booking implementation.
