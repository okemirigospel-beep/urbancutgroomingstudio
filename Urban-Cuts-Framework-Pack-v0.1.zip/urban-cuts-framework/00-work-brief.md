# Urban Cuts Grooming Studio — Framework Work Brief
Version 0.1 | Working specification | 15 September 2026

## 1. Purpose and scope
Build the initial responsive website framework for Urban Cuts Grooming Studio, a premium grooming business in Abuja, Nigeria. The primary commercial goal is to attract clients and guide them from clear service information to an appointment request. Secondary goals are academy applications/enquiries, studio visits and future product enquiries.

This assignment is the framework only. Build the structure, editable content models, section layouts, navigation and service-detail interactions. Reserve and prototype the appointment journey without activating production request storage or WhatsApp integration. Implement the complete booking functionality in a subsequent phase. Do not deploy publicly as part of this brief.

## 2. Confirmed facts
- Official name: Urban Cuts Grooming Studio.
- One location, in Abuja, Nigeria. Exact address and map listing are pending.
- Audience: primarily men, also children; the business also offers female braiding. Do not describe it as exclusively male.
- Current principal offerings: barbering/grooming, loc services, braiding and home services within Abuja.
- Manicure, pedicure, massage and spa services: coming soon. The later clarification overrides the initial general mention of manicure/pedicure as existing services.
- Products have not launched. Product names and prices will be sample content.
- Academy is operating. Five progressive training levels are requested; names, syllabuses, fees and durations below are draft examples.
- Monday–Saturday, 10 a.m.–6 p.m., Africa/Lagos timezone. Sunday closed.
- Book today, visit tomorrow at the earliest. Interpret as next calendar day in Abuja, not a confirmed rolling 24-hour rule. Sunday remains unavailable. Exact cutoff and holiday exceptions pending.
- No branch or staff selection.
- Multiple services in one request, including an adult haircut and a child's haircut.
- Later production flow must both save a request and prepare a WhatsApp summary.
- Public contact buttons should use labels rather than showing the number/email as visible text.
- No founder/team profile required in About.

## 3. Brand positioning and draft copy
Positioning: precise, professional grooming with a consistent commitment to quality. Quality is an owner-stated commitment, not an independently verified accolade. Avoid fabricated awards, customer counts, star ratings, history and years of experience.

Draft hero: “Look sharp. Feel assured.”
Supporting copy: “Professional barbering, braiding and loc care in Abuja, with attention to the details that make your look your own.”
Primary action: Explore services. Secondary: Explore the academy.

Draft About: “Urban Cuts Grooming Studio brings professional grooming and thoughtful personal service together in Abuja. From barbering to braiding and loc care, our focus is on careful work, a considered finish and an experience shaped around each client. We value quality in the result and in the way every service is delivered.”

Draft mission: “To help every client leave looking sharp and feeling confident through skilled grooming, attentive service and an uncompromising commitment to quality.”

Standards to communicate, as stated by the owner: consultation, hygiene, punctuality and personalised service. Do not invent specific sterilisation methods or guarantees. This is brand introduction copy, not a fictional origin story.

## 4. Architecture
Proposed initial architecture: one responsive homepage with section anchors, reusable components and expandable service details. Keep the content modular so Services and Academy can become separate pages later without rewriting the data. This is a proposed default, not a business constraint.

Order: Hero; Services; About/standards; Gallery; Reviews; Academy; Products coming soon; FAQ; Contact and social links; Footer. Give Services the strongest functional emphasis, with About and Reviews prominent trust support.
Navigation: Services, About, Gallery, Academy, Contact plus a primary Explore services action. Products/reviews/FAQ remain accessible through page links/footer. Avoid an overcrowded mobile menu.

## 5. Initial framework behaviour
- Working navigation, accessible mobile menu and clear section headings.
- Service categories, detail panels/dialogs and editable service content.
- Each service detail shows description, draft inclusions, sample price and status.
- A demonstration selection basket may support adding/removing services and quantities. It is not a live booking system.
- Prototype fields: name, studio/home service choice, location, preferred date/time, optional instructions. Preserve a location field as requested; suggest home address only for home visits and Abuja area for studio visits, pending refinement.
- Show a reviewable sample summary. In framework mode the final action previews the message; do not claim it was saved or sent.
- Coming-soon services/products cannot be added to a booking basket.
- Gallery uses neutral placeholders. Reviews use an honest empty state until genuine material is provided, never invented reviews.
- Academy tier comparison, FAQ accordions and contact layout work with draft data.
- Unconfigured contact/map buttons show a clear unavailable state, not fabricated destinations or dead hash links.

## 6. Future appointment specification (not a Phase 1 production task)
Journey: explore services -> add services/quantities -> select studio/home service -> provide name/location/date/time/notes -> review request -> save request -> open WhatsApp with prepared message.
Label the action “Continue on WhatsApp”. State “This is an appointment request. Your time is confirmed after availability is checked.” Working hours are not verified slot availability.
Quantities support two children receiving the same service. Optional recipient labels can distinguish services without requiring children's names. No accounts, online payments or staff picker are required.
Earliest date is tomorrow in Africa/Lagos, excluding Sunday and configured closures. Disable past dates and same-day requests. Time options must stay within working hours; a provisional 30-minute display interval may be used only in the prototype. It does not represent service duration or capacity. Final latest-start rules require real durations and operating decisions.
Persist requests server-side in production. Browser storage alone does not meet the business's saved-request requirement. Define unique request IDs, created time, selected service IDs/names/quantities and price snapshots, customer name, service mode/location, requested date/time/timezone, optional notes and request status. Validate server-side and prevent duplicate submissions on retries.
A saved request is not a confirmed appointment. A WhatsApp link opening is not proof of a sent or received message. Do not mark either as confirmed automatically.
On save failure, show retry and an explicit direct-contact fallback; never claim saved. On WhatsApp handoff failure after saving, retain the request ID and provide copy-summary and email contact. Keep personal details out of analytics and general logs. Production access controls, retention policy and privacy notice are required before saving real customer data.

Prepared-message template:
Hello Urban Cuts Grooming Studio, my name is {name}.
I would like to request:
{quantity} × {service name} — {price if approved}
Service mode: {studio/home}
Location: {location}
Preferred date: {date}
Preferred time: {time} (Abuja time)
Additional instructions: {notes or None}
Request reference: {saved ID, production only}
Please confirm availability and the final service details.

## 7. Sample content rules
All sample prices, proposed service inclusions and academy tiers must carry draft metadata and be visibly identifiable in the private framework. No fictional facts should be presented as launch-ready. Use service status values active, coming_soon and draft; separate sample price status from service availability.
No fixed/starting-price business rule has been agreed. Use “Sample price” for now and disable definitive payable totals. Prototype totals, if shown, must read “Sample estimate”. Durations remain “To be confirmed”. Add-ons are draft suggestions, not confirmed offerings.

## 8. Academy and products
The academy is operating, but the programme ladder is provisional. Each level needs title, audience, outline, fee, duration and an enquiry action. Do not claim accreditation, certificates, guaranteed income/jobs or enrolment availability without confirmation.
Products are explicitly coming soon. Show sample beard oil, beard balm and styling cream with sample prices; no purchase/cart action, stock claim, delivery promise or invented launch date.

## 9. Visual and responsive brief
Owner direction: approximately 60% white, 30% black and 10% gold. Treat as visual balance, not mandatory surface-area arithmetic. White dominates reading surfaces; black anchors typography and selected sections; gold is a restrained accent. Test text contrast; gold is not automatically suitable for small text on white.
Choose typography and a single icon family during implementation research; no final font is locked by this brief. Use the available design-research skill and preserve the owner's palette. Use a simple type hierarchy, clear service listings and minimal decoration. Placeholder imagery must retain intended aspect ratios and avoid layout shifts.
Mobile: single-column content, easy category controls, touch-friendly actions, usable service details and compact navigation. Tablet: balanced intermediate columns. Desktop: wider grids and potentially an adjacent request-summary panel. All content must remain available without hover.
Light motion only, with reduced-motion support. Keyboard-operable dialogs/accordions, labelled fields, visible focus, useful error messages and accessible contrast are baseline requirements.

## 10. Contact, map and review handling
Buttons: Message us on WhatsApp; Send us an email; Visit our Instagram; Get directions. One business contact set. Do not visibly print email or phone. Destinations will still exist in link data when configured; this is a presentation preference, not a guarantee that the underlying address/number is secret.
Show Abuja, Nigeria until the exact address arrives. Reserve a map placeholder; never guess the listing or pin. Provide directions link when supplied.
Use real customer reviews later. Review screenshots should be cleared for publication and unnecessary personal details removed. Initial review component: “Customer reviews will be added here.” No fake star aggregate or review schema.

## 11. Draft FAQ principles
Include confirmed answers for hours, location region, appointment notice, multiple services, staff allocation, home-service region and coming-soon categories. Policies on deposits, cancellation, lateness, refunds and walk-ins are unknown: use useful neutral instructions to contact the studio rather than inventing binding terms. One-day booking notice is not a promised response time.

## 12. Technical boundaries and acceptance
Developer chooses stack, hosting and content-management approach. Keep business content/config separate from rendering and use stable service IDs. No plugin installation, new backend, agent build, online checkout or public deployment is required by this planning brief.
Framework acceptance: every requested section exists; navigation and details work across mobile/tablet/desktop; active and coming-soon offerings are distinct; sample figures are labelled; no real save/send claims; multi-service demonstration is coherent if included; placeholder contacts/maps behave honestly; all copy is editable; no fabricated social proof.
Later production acceptance: real catalogue/policies/contacts approved, booking storage verified, WhatsApp message correct, duplicate/error paths tested, personal-data access restricted, mobile journey tested, search metadata and performance reviewed. No ranking promises.

## 13. Decisions still open, not framework blockers
Exact address/map/contact links; final services/prices/durations/add-ons; home-service zones/fees and scheduling; booking horizon, closing-time cutoff and holiday rules; genuine reviews; final academy tiers/intake and application fields; product details; deposit/cancellation/lateness/walk-in policies; production storage and retention; developer stack/maintenance choices. Use central configuration and pending states rather than repeatedly blocking framework work on these items.
