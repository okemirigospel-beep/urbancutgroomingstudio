# Draft FAQ

Confirmed operational facts and neutral pending-policy answers. Review before launch; remove framework-specific explanations when final content replaces samples.

**Where are you located?**

We operate from one studio in Abuja, Nigeria. The exact address and directions will be added shortly.

**What are your opening hours?**

Monday to Saturday, 10 a.m. to 6 p.m. Abuja time. We are closed on Sundays.

**Can I book for today?**

Please request your appointment at least the day before your preferred visit. Same-day requests are not available through this booking flow.

**Does choosing a time confirm my appointment?**

No. Your selection is a preferred time; the studio must confirm availability.

**Can I request more than one service?**

Yes. You can include multiple services in one request, including an adult haircut and a child’s haircut.

**Can I choose my barber?**

The website does not offer staff selection. The studio will allocate the appropriate professional.

**Do you offer home services?**

Home-service enquiries are available within Abuja. Confirm the exact location and service arrangements with the studio.

**Are manicure, pedicure and spa services available?**

These services are coming soon and cannot currently be requested through the website.

**Can I buy grooming products?**

The product range has not launched yet. Displayed products and prices are framework samples.

**Is the academy operating?**

Yes. Contact the studio about current training options. The programme details in this draft are provisional.

**What does training cost and how long does it take?**

Please confirm the current fee, duration and syllabus with the studio. Draft figures are not enrolment terms.

**Is a deposit required?**

Please ask the studio to confirm any deposit requirement before your appointment. A deposit policy has not yet been published.

**How do I cancel or reschedule?**

Contact the studio with your appointment details. Applicable notice requirements and charges must be confirmed with the studio.

**What if I am late?**

Contact the studio as soon as possible so the team can advise on your appointment.

**Do you accept walk-ins?**

Please contact the studio to check before visiting without a confirmed appointment.

**How do I contact you?**

Use the WhatsApp or email action in the contact section.

**Are the displayed prices final?**

Prices in this framework are examples. The approved service catalogue will replace them before launch.