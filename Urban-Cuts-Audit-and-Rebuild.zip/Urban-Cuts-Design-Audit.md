# Urban Cuts — Evidence-based design audit and rebuild direction
Version 1.0 · 17 September 2026

## Verdict and evidence boundary
The submitted desktop first screen is a competent wireframe but an underdeveloped premium brand presentation. Its alignment, whitespace and high-contrast primary buttons are usable foundations. The main failure is substitution: generic text, a fabricated identity and an empty media rectangle are standing in for brand evidence. Calling every element broken would be inaccurate. A font swap and more gold will not solve the composition.

Evidence examined: one 1584×739 desktop screenshot, a 1254×1254 RGBA logo and an approximately 7.85-second 720×1280 portrait video. Video checked through metadata and eight sampled frames; smoothness/audio have not been evaluated in a real website. No source code, live Urban Cuts URL, mobile screenshots or below-fold screenshots were supplied. Accordingly, observed defects and proposed checks are separated below. There are 65 substantive action items, not 1,001 invented defects.

Refero live search attempted across grooming, cinematic hospitality and Aesop-style restraint. All three returned NO_SUBSCRIPTION. No Refero styles/screens/flows were retrieved. Refero’s available design methodology and craft reference were used. Direct public website research supplies the named references below.

## Research and synthesis
These are relevant reference ingredients, not an objective ranking of the world’s best websites.

- [Pall Mall Barbers](https://www.pallmallbarbers.com/): desktop viewport inspected. Dark identity/navigation band and large image-led hero establish category and an immediate appointment action. Adopt the media/action hierarchy as the primary compositional ingredient. Reject the rotating slider, huge hero extent and lengthy prestige-heavy homepage copy. Do not import its claims or heritage.
- [Murdock London](https://www.murdocklondon.com/): desktop viewport inspected. Recognisable brand asset, disciplined dark brand colour and purposeful photographic composition. Borrow coherent brand treatment and one clear action in a media composition. Reject its shop-dominant hierarchy, crowded retail navigation and promotional typography for this booking-led business.
- [Ruffians](https://ruffians.co.uk/): desktop viewport inspected. Sparse header, centred identity and dominant real imagery. Borrow the removal of visual furniture. Reject its retail-first hero and hidden desktop navigation as Urban Cuts’ main pattern.

The reference pages were observed on this research date; future content can change. Source-derived observations are intentionally limited. The following tokens and exact composition are proposed Urban Cuts adaptations, not claimed source measurements.

## Recommended design lock
Direction: a disciplined grooming brand with an atmospheric barbering film and a fast route to a useful service menu.
Preserve: authentic supplied logo; white as the primary lower-page surface; near-black hero/header; restrained amber-gold; recognisable grooming action; straightforward services.
Primary reference role: Pall Mall media/booking hierarchy. Secondary roles: Murdock brand consistency, Ruffians reduction of visual clutter.
Reject: SaaS card-wall homepage, invented UC monogram, grey UC media panels, gold gradients everywhere, decorative italics, huge slogan over blank space, automatic sliders and excessive motion.
The user’s 60/30/10 palette is a broad overall preference, not a mandate to paint exactly 10% of the interface gold. Never repaint the supplied logo to fit a preset.

## Proposed layout across the site
1. Compact near-black navigation: supplied brand asset, Services / About / Gallery / Academy / Contact, and View services. No cart for unreleased products. Full supplied stacked logo can appear prominently in hero/footer while a clean horizontal version is pending.
2. Dark atmospheric hero: left readable text, right a portrait-aware video region feathering into the dark text area. No bordered media card. Start near a 55/45 text/media division and inspect actual frames. The supplied portrait source is unsuitable for unexamined full-width cover cropping: at 1440×600 only about 23% of its source height remains visible when filled horizontally.
3. Copy proposal: “Grooming, down to the detail.” Supporting line: “Barbering, braids and loc care in Abuja. Choose your service and request your preferred appointment.” Primary View services; quieter View our work. Do not advertise live booking if still a framework.
4. Useful information strip: Abuja • Monday–Saturday, 10am–6pm • Book at least the day before. Move sample notices to compact preview UI without hiding that prices are provisional.
5. White service menu: categories and concise price/detail rows. Put detailed explanations behind accessible expansion; keep main options easily scanned. No need to illustrate every service with a generic icon.
6. Work/gallery evidence: curated images once supplied; do not duplicate stock footage as the studio portfolio. Keep placeholders truthful and visually restrained.
7. About/standards: short narrative paired with concise practices, no imaginary history or gratuitous statistics.
8. Reviews: two or three approved readable quotations when supplied, no autoplay carousel or fictional stars.
9. Academy: a purposeful learning pathway with five expandable levels and a dedicated enquiry action, not a pricing-plan clone.
10. Products: compact coming-soon preview.
11. FAQ: operational answers first, neutral pending-policy copy where details are unknown.
12. Contact/footer: directions, hours and labelled contact links; strong closing service action. Exact location remains pending.

## Proposed design tokens
- Surfaces: white #FFFFFF; near-black #111111; muted text #575757; light border #E4E4E4. Gold/amber provisional #F5A000, to be aligned with a clean logo source. Black text on amber; do not use amber for small text on white without testing.
- Type: Barlow Condensed 600 for display, Manrope 400/500/600 for body/navigation, subject to licensed font availability. These are proposed options, not mandatory downloads or identified screenshot fonts. No more than two families.
- Desktop H1 around 64–76px; mobile 38–48px; H2 32–44px; body 16–18px; navigation 15–16px. Tune line breaks from actual renders. No hard-coded desktop line breaks that break mobile.
- Content max-width around 1280px; responsive gutters 24px mobile, 48–64px desktop; 8px spacing basis. Section padding roughly 64–96px desktop, 40–64px mobile.
- Buttons about 48–52px high, minimal 2–4px corner radius, no default heavy shadow. Consistent 18–20px action icons, generous activation areas.
- Motion: 150–250ms for simple controls; background film excepted and controllable. All are starting values, not substitute acceptance tests.

## Logo and video specification
The source logo has transparency, but visible edge artefacts make a clean master preferable. Preserve the original file; do not invent vector paths or call an auto-trace the original. Do not stretch the square lockup into a horizontal rectangle. Verify legibility on dark and light backgrounds, accounting for its white letters. Request approved horizontal/symbol variants before compact header/favicons are finalised.

The video is already small (~1.06 MB) but uses HEVC and contains audio. Produce a web-compatible silent H.264 derivative and a matching lightweight poster. Use muted, playsInline, loop and a poster-first fallback; autoplay must be treated as best-effort. See [MDN video documentation](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/video).

“Faint” should mean reduced visual competition, not nearly invisible imagery. Use an independent dark overlay with stronger opacity near text and lighter opacity over the action. Start around 60–80% near text and 15–30% over the focal area, then measure/readjust across frames. Do not apply opacity to text and video together. Keep facial detail and tools visible. A subtle fade-in when playback is ready is acceptable; repeated whole-hero fade-to-black is not.

The clip has a visible editing mark and black bands in some sampled frames. Obtain a clean version and confirm commercial usage permission before launch. This is an asset-quality requirement tied to the actual file, not a claim that permission is absent. Stock imagery must not imply the filmed premises or service is Urban Cuts work.

Provide a pause/play control, do not autoplay for prefers-reduced-motion, and keep a poster fallback when playback fails. Pause offscreen; never override a visitor’s explicit pause choice. Continuous automatic motion alongside other content needs pause/stop/hide consideration under [W3C guidance](https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide.html).

## Prioritised findings and checks
P0 = identity/truth blocker. P1 = high-impact design or usability. P2 = refinement.

### A. Observed screenshot and asset findings

| ID | Priority | Finding and evidence | Implementation |
|---|---|---|---|
| 01 | P0 | **Invented UC header identity.** The screenshot uses a UC monogram instead of the supplied logo. | Replace the invented artwork with the owner asset. Keep original proportions and colours; do not approximate it with text or an icon. |
| 02 | P0 | **Brand spelling conflict.** The supplied logo reads URBANCUT; the screenshot and earlier brief say URBAN CUTS. | Keep the supplied artwork unchanged, centralise the text brand name and obtain the owner’s canonical spelling before launch. |
| 03 | P1 | **Empty hero media.** The right-hand panel is a grey UC placeholder occupying much of the hero. | Replace it with the supplied grooming footage and a matching poster, with controlled framing. |
| 04 | P1 | **No visible grooming activity.** There is no person, tool use or finished hairstyle in the first screen. | Make recognisable grooming action visible immediately; footage is atmosphere, not proof of Urban Cuts workmanship. |
| 05 | P1 | **Headline carries almost all visual weight.** Very heavy, oversized copy dominates the left side while the media offers no information. | Reduce display weight/size and give the moving image meaningful visual emphasis. |
| 06 | P1 | **Headline is interchangeable.** Look sharp. Feel assured. could fit many brands. | Propose “Grooming, down to the detail.” with an immediately legible Abuja barbering description. Test against actual owner voice. |
| 07 | P1 | **Critical category/location is tiny.** GROOMING, CONSIDERED. / ABUJA appears as tiny widely tracked text. | Use “Barbering • Braids • Locs / Abuja” at a readable size, without ornamental punctuation overload. |
| 08 | P1 | **Microcopy is overused.** Several tiny all-caps labels sit above, below and inside the hero panel. | Delete decorative labels; keep only information that answers what, where, when or next step. |
| 09 | P2 | **Internal image-study label is visible.** URBAN CUTS / IMAGE STUDY appears inside the placeholder. | Remove art-direction notes from customer-facing media. |
| 10 | P2 | **Placeholder caption is visible.** Studio portrait placeholder is rendered inside the panel. | Use a real poster; keep placeholder status in content metadata or reviewer mode. |
| 11 | P2 | **Hero frame is overdrawn.** A large grey rectangle contains another thin rectangular frame. | Remove nested framing; let the image/video form the surface. |
| 12 | P2 | **Decorative arrow has unclear purpose.** A small diagonal arrow sits at the lower corner of the placeholder. | Remove it unless a clearly named media action exists. |
| 13 | P1 | **Action icons imply outbound movement.** The same diagonal-arrow motif appears on internal service/academy actions. | Use no icon or a right arrow for continuation; reserve external-link indicators for external navigation. |
| 14 | P2 | **Icon scale varies.** Large bold arrows on black buttons contrast with tiny caption arrows. | Use one SVG icon family and consistent optical sizes, typically 18–20px for action icons. |
| 15 | P1 | **Navigation looks small beside the hero.** Compact nav text is visually overwhelmed by the display headline. | Use roughly 15–16px navigation with clear spacing and at least 44px practical hit areas. |
| 16 | P2 | **Header branding is duplicated.** UC, separator and a second textual wordmark create multiple identity elements. | Use a single approved logo treatment; do not add a competing invented wordmark. |
| 17 | P1 | **Academy competes at the conversion point.** An academy link sits beside the main hero service action. | Move the academy emphasis to its own section and navigation; use View our work as the quieter hero secondary action. |
| 18 | P1 | **Hours absent from first screen.** The supplied viewport contains no operating hours. | Add a useful strip: Abuja • Mon–Sat 10am–6pm • Request at least one day ahead. |
| 19 | P1 | **Notice requirement absent from first screen.** Customers cannot see the no-same-day rule here. | Surface the rule close to service discovery and repeat it in the request flow. |
| 20 | P2 | **Service footer labels are difficult to scan.** Tiny labels below a horizontal rule repeat information already in the paragraph. | Replace them with the useful hours/location strip rather than additional typography decoration. |
| 21 | P1 | **Muted accent does not match uploaded brand.** Screenshot accents are brownish/muted; supplied emblem is vivid amber-orange gold. | Extract a representative brand swatch during implementation and use it sparingly; provisional UI accent #F5A000, not a verified brand standard. |
| 22 | P1 | **Review-mode notice dominates the top edge.** A full-width private-framework banner occupies prime brand space. | Retain honesty with a compact reviewer badge and labelled sample prices; do not make development terminology the brand’s opening statement. |
| 23 | P1 | **No service selection content visible.** The first 739px-tall screenshot contains only header and hero. | Bring the service-section title into the next visual beat; avoid a hero taller than needed on desktop. |
| 24 | P2 | **Media captions add clutter without proof.** Precision. Care. Your own style. and Abuja, NG flank the image bottom. | Remove duplicated location and slogan furniture; give that space to useful context or nothing. |
| 25 | P0 | **Logo is not a clean web-ready export.** The supplied 1254×1254 RGBA PNG has visible jagged/halo-like edge artefacts and substantial empty space. | Use it provisionally on a dark surface; request the original SVG/PDF or clean high-resolution export. Do not redraw or apply destructive filters. |
| 26 | P1 | **Stacked logo conflicts with a short header.** The supplied full mark is tall with a small descriptor. | Preserve full logo in the hero/footer; request an approved horizontal/symbol-only version for compact navigation. Use a contained full asset until that arrives. |
| 27 | P1 | **Source clip is portrait.** Video is 720×1280, about 7.85 seconds overall. | Prefer a portrait-aware media region on desktop; do not blindly cover an entire wide screen. |
| 28 | P1 | **Source video needs browser-oriented encoding.** Video stream is HEVC/H.265 and includes AAC audio. | Create a silent H.264 MP4 web derivative with fast-start metadata; optional WebM. Keep the original intact. |
| 29 | P1 | **Embedded editing mark and bars are visible.** Sampled frames show a small editing mark near the top and black bands in parts of the clip. | Use current clip for private layout testing; obtain a clean licensed original before public launch. Do not conceal the mark as a substitute for that source. |
| 30 | P1 | **Loop is not naturally seamless.** Sampled frames change framing and show an internal cut; the last scene differs from the first. | Inspect start/end playback; select a suitable motion segment or a subtle dissolve if appropriate. Never reverse barber/tool movement to fake a loop. |

### B. Required checks and design prescriptions — not established current bugs

| ID | Priority | Risk/check | Implementation and acceptance |
|---|---|---|---|
| 31 | P1 | **Video text contrast.** A faint wash can destroy both legibility and the grooming image. | Apply overlay only to video, not its parent text container; test brightest frames against text. Start with a left-heavy dark gradient, tune by inspection. |
| 32 | P1 | **Video motion control.** Continuous background movement needs a usable stop mechanism. | Provide keyboard-accessible Pause video/Play video; stop automatic motion for reduced-motion preferences. |
| 33 | P1 | **Autoplay fallback.** Browser autoplay may fail. | Show a matching poster first; muted playsInline loop; catch play failure and leave a usable still hero. |
| 34 | P1 | **Mobile crop.** Desktop object-fit settings may crop away faces/hands on mobile. | Set and inspect focal positioning separately at 390px and desktop; keep grooming action visible throughout the loop. |
| 35 | P2 | **Offscreen playback.** Video can keep decoding when no longer visible. | Pause when hero leaves viewport or document is hidden; preserve a user’s explicit paused state when returning. |
| 36 | P1 | **Network restraint.** Hero media may delay the first useful screen. | Reserve dimensions, optimise poster, serve one video instance and use a still for reduced-motion/data-saving where supported. |
| 37 | P1 | **Font-family discipline.** Exact current font cannot be identified reliably from pixels. | Inspect computed styles. Proposed display: Barlow Condensed semibold, title case; body/navigation: Manrope regular/medium. Use licensed files and no third family. |
| 38 | P1 | **Body legibility.** Lower-page text size and line lengths are unverified. | Target 16–18px body text, 1.5–1.65 line height, around 55–70 characters per prose line. |
| 39 | P1 | **Gold contrast.** Brand amber on white may be weak for small text. | Use black text on amber buttons, dark text on white, amber mostly as decoration on white; measure contrast rather than assume. |
| 40 | P1 | **Shared spacing.** Other sections may have inconsistent container edges. | Use a shared max-width around 1280px, 24px mobile gutters and 48–64px desktop gutters; tune to screenshot comparisons. |
| 41 | P1 | **Header scroll behaviour.** Sticky behaviour is untested. | Prefer a stable compact dark header; reserve its layout height and set scroll-margin for anchored sections. |
| 42 | P1 | **Mobile navigation.** Only desktop screenshot supplied. | Use labelled Menu button, clear close action, Escape handling, sensible focus order and focus restoration. |
| 43 | P1 | **Keyboard path.** Screenshot cannot establish semantic controls. | Use real links/buttons, visible focus, skip-to-content and keyboard-operable service details/FAQ. |
| 44 | P1 | **Touch affordances.** Pointer size cannot be determined from screenshot. | Give compact icons at least 44×44px practical activation areas; no hover-only content. |
| 45 | P1 | **Services presentation.** Lower service section not supplied. | Use a clean menu-style service list with category, name, short description, price and detail action; avoid a wall of identical cards. |
| 46 | P1 | **Service status clarity.** Upcoming treatments can be mistaken for current offerings. | Separate manicure/pedicure/spa/massage as coming soon, with no active selection controls. |
| 47 | P1 | **Sample-price integrity.** Prototype prices could look payable. | Show sample labels in private preview and centralise values; no production total until prices approved. |
| 48 | P1 | **Multi-person basket.** An adult and child booking requires more than a single select. | Preserve quantities and multiple line items; keep service details separate from Add/Remove controls. |
| 49 | P1 | **Confirmation language.** A selected time is not a held slot. | Use preferred date/time, pending confirmation; preserve next-day Abuja date rules and Sunday exclusion. |
| 50 | P1 | **About credibility.** Premium adjectives do not establish standards. | Use concise owner-confirmed consultation, hygiene and attention-to-detail practices; no fake origin story. |
| 51 | P1 | **Gallery evidence.** Stock atmosphere must not become a portfolio claim. | Separate owner work from stock hero imagery; use true service labels and honest placeholders. |
| 52 | P1 | **Reviews authenticity.** No review section was inspected. | Use approved real quotations; never generate names/ratings. Reserve an empty state in private preview. |
| 53 | P1 | **Review readability.** Chat screenshots may expose details and be unreadable on mobile. | Transcribe approved quotations, redact unrelated personal information and preserve source attribution where allowed. |
| 54 | P1 | **Academy comparison.** Five pricing cards can resemble a generic SaaS plan wall. | Use a progressive five-level list with expandable curriculum and a shared enquiry action; label provisional fees. |
| 55 | P1 | **Products weight.** Products have not launched. | Use a short coming-soon preview lower down; no dominant ecommerce hero or empty shopping cart. |
| 56 | P1 | **FAQ usefulness.** Generic answers may invent policy. | Prioritise notice period, hours, studio/home service and confirmation; mark deposits/cancellation terms pending. |
| 57 | P1 | **Contact completion.** Address and contact targets are still pending. | Use labelled actions, real configured links only, no guessed map pin; distinguish unavailable preview controls. |
| 58 | P2 | **Social-media clutter.** Live feeds can distract from service selection. | Use restrained outbound links rather than autoplay social embeds or follower counters. |
| 59 | P1 | **Responsive extremes.** Tablet/short laptop/zoom views remain untested. | Inspect 360, 390, 768, 1024, 1440 and 1920px plus 200% zoom; no horizontal page overflow or clipped headings. |
| 60 | P1 | **Layout stability.** Fonts and media can shift the interface. | Reserve media sizes, use a compatible font fallback and avoid layout-changing entrance effects. |
| 61 | P2 | **Motion restraint.** Animation quantity is not a quality measure. | Use brief opacity/transform transitions; no scroll hijacking, parallax text, cursor effects or per-letter hero reveals. |
| 62 | P1 | **Production scope.** A redesign can accidentally expand into platform work. | Preserve existing working functionality; do not provision databases, payments or an AI agent during a visual revision. |
| 63 | P1 | **Local delivery.** A remote preview is not the owner’s localhost. | Run on the owner machine bound to 127.0.0.1; no Sites, tunnels or Vercel deployment without instruction. |
| 64 | P1 | **Search metadata.** SEO cannot be assessed from the screenshot. | One descriptive H1, semantic headings, truthful Abuja title/description and indexable production content; keep review builds noindex. |
| 65 | P1 | **Verification evidence.** Code compiling does not prove design quality. | Render full pages and interactions, compare against reference lock and fix visible drift before claiming completion. |

## What is needed from the owner
Needed to complete the actual implementation audit:
1. Current project folder/repository or source ZIP, with secrets excluded. A localhost URL alone cannot be opened from another machine.
2. Full-page desktop and mobile screenshots or access to a reviewable site; the current screenshot shows only the first screen.
3. Final written brand spelling: URBANCUT, URBAN CUT, or Urban Cuts Grooming Studio. Keep artwork intact until answered.
4. Original logo export, ideally SVG/PDF plus an approved horizontal and symbol-only version. Current PNG is usable provisionally.
5. Clean source video without embedded editing marks; confirmation it may be used commercially. Prefer a landscape take if full-width desktop film is essential. Current portrait source can support the recommended composition.

Needed for a convincing final site, but not blockers to rebuilding the framework:
6. Actual studio/result photographs; a curated six-to-twelve image set is more useful than dozens of mixed-quality shots.
7. Approved real review text/screenshots with publication permission and attribution preference.
8. Final service list/prices and the three services to prioritise commercially.
9. Exact address/map listing, configured contact and social links.
10. Confirmed academy details and remaining policies before launch.
No need to answer all the previous business questionnaire again. These inputs address gaps exposed by this audit.

## Tools and plugins
- Refero: primary research/design authority; present but live research was blocked by inactive subscription. Restore only if further live Refero research is desired; it is not needed to invent a new design from scratch.
- Vercel/Next.js/React skills: implementation guidance and later Vercel readiness, not permission to deploy now.
- One browser-testing tool: required for visual/interaction verification. Existing browser capability, Playwright or agent-browser in the implementation environment; do not install multiple overlapping stacks.
- Git/GitHub: inspect existing project and keep a reversible local commit/branch; connect/push only to an authorised repository. Git alone suffices for local history.
- Lucide or another single established SVG icon library: an application dependency, not a design plugin; do not mix with emoji or Unicode arrows.
- FFmpeg: media encoding utility, not a plugin. Use for authorised video derivatives; keep originals.
- Supabase: no new provisioning for this design pass. Preserve an existing authorised integration if present.
- Fal/image generation: optional for explicitly requested supporting art; unnecessary for the supplied logo/video and never for fabricated customer evidence.
- Figma/21st.dev/GSAP: optional, not prerequisites. Component galleries do not replace art direction; ordinary CSS is sufficient for the requested light animation.
Do not buy, activate subscriptions or install plugins merely because they appear in this audit.

## Execution and acceptance
Sequence: inspect repository -> preserve baseline -> settle artwork usage/record open spelling -> apply reference lock -> implement header/hero/services first -> carry tokens through all sections -> test actual rendered pages -> report residual limitations.

Measure success against concrete outcomes: recognisable grooming image on arrival; supplied identity used faithfully; service action immediately clear; no tiny essential labels; readable text across video frames; all controls keyboard/touch usable; no deceptive booking state; no coming-soon selection; no overflow at target sizes; reduced-motion and failed-media fallbacks work; relevant production build/type checks pass; local preview verified. Performance lab reports are diagnostic, not fabricated promises of real-user Core Web Vitals.

This report is a specification and asset audit. No website source was changed or deployed in this turn.
